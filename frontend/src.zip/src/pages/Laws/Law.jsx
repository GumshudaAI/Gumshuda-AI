import Navbar from '../../components/Navbar/Navbar'
import './Law.scss'

export default function Law() {
    return(
        <div className='root'>
            <Navbar/>
            <div className='law-main'>
                <h2>CHILDREN RELATED LAW</h2>
                <div className='content'>

                </div>
            </div>
        </div>
    );
}
